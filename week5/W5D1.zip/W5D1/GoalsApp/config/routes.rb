Rails.application.routes.draw do
  # get 'goals/index'
  # 
  # get 'sessions/new'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

    resources :users
    resource :session
    resources :goals
end






