class GoalsController < ApplicationController
  def index
  end
end
