require 'rails_helper'

RSpec.describe UsersController, type: :controller do
  describe 'GET #new' do
    it "renders a new user page" do
      get :new
      expect(response).to render_template('new')
    end
  end 
  
  describe 'POST #create' do
    context 'with valid params' do
      it "saves user" do
        post :create, params: {user: {username: 'test', password: 'password' } }
        expect(User.find_by_username('test')).not_to be_nil
      end
      it "redirects to users goals page" do
        post :create, params: {user: {username: 'test', password: 'password' } }
        expect(response).to redirect_to(goals_url)
      end
      
    end 
    
    context 'with invalid params' do 
      it "flashes errors and redirects somewhere" do
        post :create, params: {user: {username: 'test', password: '' } }
        expect(flash[:errors]).to be_present
        expect(response).to render_template('new')
      end
    end
  end
end
