require 'rails_helper'

RSpec.describe User, type: :model do
  

  
    it { should validate_presence_of(:username) }
    it { should validate_presence_of(:password_digest) }
    it { should validate_length_of(:password).is_at_least(6) }

    
    it { should have_many(:goals)}
    
    it "finds a user by credentials" do 
      user = FactoryBot.build(:user)
      user.save!
      found = User.find_by_credentials(user.username, user.password)
      expect(found).to eq(user)
      
    end 
    
    it "returns nil for bad credentials" do
      user = FactoryBot.build(:user)
      user.save!
      found = User.find_by_credentials(user.username, 'not_password')
      expect(found).to be(nil)
    end 
    
    it "assigns a session token" do
      user = FactoryBot.build(:user)
      user.save
      expect(user.session_token).not_to be_nil
    end
    
    it "saves password_digest to db" do
      user = FactoryBot.build(:user)
      user.save
      expect(user.password_digest).not_to be_nil
    end
    
  
end
