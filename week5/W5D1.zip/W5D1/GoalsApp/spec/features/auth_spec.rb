# spec/features/auth_spec.rb

require 'spec_helper'
require 'rails_helper'

feature 'the signup process' do
  background :each do 
    visit new_user_url
  end 
  scenario 'has a new user page' do 
      expect(page).to have_content('Username')
      expect(page).to have_content('Password')
      expect(page).to have_content("Sign Up")
  end 
  feature 'signing up a user' do
    user = FactoryBot.build(:user)
    scenario 'shows username on the homepage after signup' do 
      fill_in 'Username', with: user.username
      fill_in 'Password', with: user.password
      click_button 'Sign Up'
      expect(page).to have_content(user.username)
    end 
  end
end

feature 'logging in' do
  user = FactoryBot.build(:user)
  scenario 'shows username on the homepage after login' do
    visit new_session_url 
    fill_in 'Username', with: user.username
    fill_in 'Password', with: user.password
    click_button 'Sign In'
    expect(page).to have_content(user.username)
  end
  
end

feature 'logging out' do
  scenario 'begins with a logged out state'do
    visit goals_url
    expect(page).to have_content('Sign In')
    expect(page).to have_content('Sign Up')
  end
  scenario 'doesn\'t show username on the homepage after logout' do
    visit goals_url
    user = FactoryBot.build(:user)
    expect(page).not_to have_content(user.username)
  end

end