

Array.prototype.myEach = function (callback) {
  for (let i = 0; i < this.length; i++) {
    callback(this[i]);
  }
};

let myFunc = function (el) {
  console.log(el);
};

// console.log([1,2,3,4].myEach(myFunc));

Array.prototype.myReduce = function (callback, a) {
  let acc = a;
  let newArray = this;
  if (a === undefined) {
    acc = this[0];
    newArray = this.slice(1);
  }
  newArray.myEach(function(el) {acc = callback(acc,el);});
  return acc;
};

let myFunc2 = function (acc,el) {
  return acc + el;
};

// console.log([1,2,3,4].myReduce((acc,el) => acc + el ));


Array.prototype.myMap = function (callback) {
  let result = [];
  this.myEach(function(el) {
      result.push(callback(el));
    }
  );
  return result;
};
