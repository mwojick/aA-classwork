Array.prototype.uniq = function() {
  let result = [];
  this.forEach(function(el) {
    if (result.includes(el)) {
    } else {
      result.push(el);
    }
  });
  return result;
};

// console.log([1,1,2,3,3].uniq());

Array.prototype.twoSum = function() {
  console.log(this);
  let pairs = [];
  for (let i = 0; i < this.length-1; i++) {
    for (let j = i+1; j < this.length; j++) {
      if (this[i] + this[j] === 0) {

        pairs.push([i,j]);
      }
    }
  }
  return pairs;
};
// console.log([2,-2,0,1,0,-1,5,6].twoSum());


Array.prototype.transpose = function () {
  let transposed = [];
  for (var i = 0; i < this[0].length; i++) {
    transposed.push([]);
    for (var j = 0; j < this.length; j++) {
      // transposed[i].push(this[j][i]);
      transposed[i][j] = this[j][i];
    }
  }
  return transposed;
};

// console.log([[1,1,1,1],[2,2,2,2],[3,3,3,3]].transpose());




//
