class PostsController < ApplicationController
  # before_action :require_author(params[:id]), only: [:edit, :update]

  def new
    @post = Post.new
    @post.sub_id = params[:sub_id]
  end
  def create
    @post = Post.new(post_params)
    @post.author_id = current_user.id

    if @post.save
      redirect_to post_url(@post)
    else
      flash.now[:errors] = @post.errors.full_messages
      render :new
    end
  end

  def edit
    @post = Post.find(params[:id])
    redirect_to post_url(@post) unless @post.author_id == current_user.id
  end
  def update
    @post = Post.find(params[:id])
    redirect_to post_url(@post) unless @post.author_id == current_user.id

    if @post.update(post_params)
      redirect_to post_url(@post)
    else
      flash.now[:errors] = @post.errors.full_messages
      render :edit
    end
  end

  def show
    @post = Post.find(params[:id])
  end

  def post_params
    params.require(:post).permit(:title,:url,:content)
  end
end
