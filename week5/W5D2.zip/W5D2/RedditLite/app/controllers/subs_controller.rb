class SubsController < ApplicationController
  # before_action :require_moderator(params[:id]), only: [:edit, :update]

  def new
    @sub_reddit = Sub.new
  end
  def create
    @sub_reddit = Sub.new(sub_params)
    @sub_reddit.moderator_id = current_user.id

    if @sub_reddit.save
      redirect_to sub_url(@sub_reddit)
    else
      flash.now[:errors] = @sub_reddit.errors.full_messages
      render :new
    end
  end

  def edit
    @sub_reddit = Sub.find(params[:id])
    redirect_to sub_url(@sub_reddit) unless @sub_reddit.moderator_id == current_user.id
  end
  def update
    @sub_reddit = Sub.find(params[:id])
    redirect_to sub_url(@sub_reddit) unless @sub_reddit.moderator_id == current_user.id
    if @sub_reddit.update(sub_params)
      redirect_to sub_url(@sub_reddit)
    else
      flash.now[:errors] = @sub_reddit.errors.full_messages
      render :edit
    end
  end

  def index
    @subs = Sub.all
  end
  def show
    @sub_reddit = Sub.find(params[:id])
  end

  def sub_params
    params.require(:sub).permit(:title,:description)
  end

end
