class Api::SessionsController < ApplicationController
end
