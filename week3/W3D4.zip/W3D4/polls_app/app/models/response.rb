# == Schema Information
#
# Table name: responses
#
#  id         :bigint(8)        not null, primary key
#  user_id    :integer          not null
#  answer_id  :integer          not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Response < ApplicationRecord
  validate :not_duplicate_response
  
  belongs_to :answer_choice,
  class_name: :AnswerChoice,
  primary_key: :id,
  foreign_key: :answer_id
  
  belongs_to :respondent,
  class_name: :User,
  primary_key: :id,
  foreign_key: :user_id
  
  has_one :question,
  through: :answer_choice,
  source: :question
  
  
  def sibling_responses
    self.question.responses.where.not(id: self.id)
  end
  
  def respondent_already_answered?
    sibling_responses.any? do |response|
      response.user_id == self.respondent.id
    end
  end
  
  def respondent_is_owner?
    self.answer_choice.question.poll.user_id == self.user_id
  end 
  
  def not_duplicate_response
    if self.respondent_already_answered?
      errors[:duplicate] << "Can't have duplicate response!"
    end
  end 
  
end
