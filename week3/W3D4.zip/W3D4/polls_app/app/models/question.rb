# == Schema Information
#
# Table name: questions
#
#  id         :bigint(8)        not null, primary key
#  poll_id    :integer          not null
#  text       :text             not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Question < ApplicationRecord
  validates :text, presence: true
  
  has_many :answer_choices,
  class_name: :AnswerChoice,
  primary_key: :id,
  foreign_key: :question_id
  
  belongs_to :poll,
  class_name: :Poll,
  primary_key: :id,
  foreign_key: :poll_id
  
  has_many :responses,
  through: :answer_choices,
  source: :responses
  
  def results
    
    choices = self.answer_choices.includes(:responses)    
    results = {}
    
    choices.each do |choice|
      results[choice] = choice.responses.length
    end 
    
    ans = results.map do |k,v|
      
      [k.text, v]
    end
    
    ans.to_h
  end 
  
  
end
