# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

User.destroy_all
Poll.destroy_all
Question.destroy_all
AnswerChoice.destroy_all
Response.destroy_all

# ApplicationRecord.transaction do
#   User.import(
#     [:username],
#     [
#     ['User1'],
#     ['User2'],
#     ['User3'],
#     ['User4'],
#     ['User5']
#     ]
#   )
# 
#   Poll.import(
#     [:title, :user_id],
#     [
#       [],[],[],[],[]
#     ]
#   )
# end

3.times do 
  username = Faker::Zelda.character
  user = User.create(username: username)
  
  3.times do
    title = Faker::Zelda.game
    poll = Poll.create(title: title, user_id: user.id)
    
    question1 = Question.create(text: "Do you like this game?", poll_id: poll.id)
    question2 = Question.create(text: "Do you play this game?", poll_id: poll.id)
    
    answer11 = AnswerChoice.create(text: "Yes.", question_id: question1.id)
    answer12 = AnswerChoice.create(text: "No.", question_id: question1.id)
    answer21 = AnswerChoice.create(text: "Yes.", question_id: question2.id)
    answer22 = AnswerChoice.create(text: "No.", question_id: question2.id)
    
  end

end 

Response.create(user_id: 1, answer_id: 13)
Response.create(user_id: 1, answer_id: 31)

Response.create(user_id: 2, answer_id: 2)
Response.create(user_id: 2, answer_id: 30)

Response.create(user_id: 3, answer_id: 1)
Response.create(user_id: 3, answer_id: 14)







#